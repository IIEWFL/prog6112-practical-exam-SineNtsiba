/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package imovietickets;

import org.junit.Test;

public class MovieTicketsTest {

   
    //it verifies that the method returns the correct total sales value.
    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        MovieTickets report = new MovieTickets();
        
        int[] napoleonSales = {3000, 1500, 1700}; // Expected total: 6200
        int totalNapoleon = report.TotalMovieSales(napoleonSales);
        assertEquals(6200, totalNapoleon, "Total sales for Napoleon should be 6200");
        
        int[] oppenheimerSales = {3500, 1200, 1600}; // Expected total: 6300
        int totalOppenheimer = report.TotalMovieSales(oppenheimerSales);
        assertEquals(6300, totalOppenheimer, "Total sales for Oppenheimer should be 6300");
    }

    //this test determines the top-performing movie based on the total sales.
    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        MovieTickets report = new MovieTickets();
        
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300};
        
        String topMovie = report.TopMovie(movies, totalSales);
        assertEquals("Oppenheimer", topMovie, "Top performing movie should be Oppenheimer");
    }

    public void assertEquals(int i, int totalNapoleon, String total_sales_for_Napoleon_should_be_6200) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void assertEquals(String oppenheimer, String topMovie, String top_performing_movie_should_be_Oppenheime) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
