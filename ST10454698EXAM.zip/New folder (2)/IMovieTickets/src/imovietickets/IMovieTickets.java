/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package imovietickets;

/**
 *
 * @author User
 */
public interface IMovieTickets {
    // method to calculate total sales for a given movie
    int TotalMovieSales(int[] movieTicketSales);

    // method to find the top performing movie based on total sales
    String TopMovie(String[] movies, int[] totalSales);
}
