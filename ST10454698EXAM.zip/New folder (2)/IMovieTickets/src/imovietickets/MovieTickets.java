/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package imovietickets;

/**
 *
 * @author User
 */
public class MovieTickets implements IMovieTickets {

    //hard-coded data for ticket sales per month for each movie
    public static final String[] movies = {"Napoleon", "Oppenheimer"};
    public static final int[][] ticketSales = {
        {3000, 1500, 1700}, //sales for "Napoleon" in Jan, Feb, Mar
        {3500, 1200, 1600}  //sales for "Oppenheimer" in Jan, Feb, Mar
    };

    public static void main(String[] args) {
        MovieTickets report = new MovieTickets();
        
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println("--------------------------------");

        //display monthly sales for each movie
        System.out.printf("%-12s%-8s%-8s%-8s\n", "", "JAN", "FEB", "MAR");
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("%-12s", movies[i]);
            for (int j = 0; j < ticketSales[i].length; j++) {
                System.out.printf("%-8d", ticketSales[i][j]);
            }
            System.out.println();
        }
        
        System.out.println();
        
        //calculate and display total sales for each movie
        int[] totalSales = new int[movies.length];
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = report.TotalMovieSales(ticketSales[i]);
            System.out.println("Total movie ticket sales for " + movies[i] + ": " + totalSales[i]);
        }

        //determine and display the top-performing movie
        String topMovie = report.TopMovie(movies, totalSales);
        System.out.println("\nTop performing movie: " + topMovie);
    }

    //method to calculate the total sales for a given movie
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sales : movieTicketSales) {
            total += sales;
        }
        return total;
    }

    //method to determine the top performing movie
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxSales = totalSales[0];
        int maxIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                maxIndex = i;
            }
        }
        return movies[maxIndex];
    }
}
