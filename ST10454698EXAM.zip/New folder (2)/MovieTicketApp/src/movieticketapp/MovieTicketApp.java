/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketapp;

/**
 *
 * @author User
 */
import javax.swing.*; 
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;

public class MovieTicketApp extends JFrame implements ActionListener {
   
    public JComboBox<String> movieComboBox = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});
    public JTextField ticketPriceField = new JTextField(); //field for entering ticket price
    public JTextField numberOfTicketsField = new JTextField(); //field for entering number of tickets
    public JTextArea reportArea = new JTextArea(); //area to display the generated report
    public JMenuItem exitMenuItem = new JMenuItem("Exit"); //exit menu item
    public JMenuItem processMenuItem = new JMenuItem("Process"); //process menu item to calculate total
    public JMenuItem clearMenuItem = new JMenuItem("Clear"); //clear menu item to reset fields

    public MovieTicketApp() {
        // Set up the frame
        setTitle("Movie Tickets");
        setSize(400, 300); // Set the size of the window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close on exit
        setLayout(null); 
        
        //add labels and input fields to the frame
        addComponent(new JLabel("Movie:"), 10, 10, 100, 25); 
        addComponent(movieComboBox, 150, 10, 150, 25);
        addComponent(new JLabel("Ticket Price:"), 10, 50, 100, 25);
        addComponent(ticketPriceField, 150, 50, 150, 25);
        addComponent(new JLabel("Number of Tickets:"), 10, 90, 130, 25);
        addComponent(numberOfTicketsField, 150, 90, 150, 25);

       
        reportArea.setBounds(10, 130, 350, 100);
        reportArea.setEditable(false); //make the report area non-editable
        add(reportArea);

        // Set the menu bar with menu items
        setJMenuBar(createMenuBar());
        // Add action listeners for menu items
        exitMenuItem.addActionListener(this);
        processMenuItem.addActionListener(this);
        clearMenuItem.addActionListener(this);
    }

    // Helper method to add components to the frame
    public void addComponent(JComponent component, int x, int y, int width, int height) {
        component.setBounds(x, y, width, height);
        add(component);
    }

    // Create the menu bar and its items
    public JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File"); // File menu for Exit
        JMenu toolsMenu = new JMenu("Edit"); // Edit menu for Process and Clear
        fileMenu.add(exitMenuItem);
        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    // Handle action events for the menu items
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == exitMenuItem) {
            System.exit(0); // Close the application
        } else if (e.getSource() == processMenuItem) {
            processInput(); // Process the inputs and generate report
        } else if (e.getSource() == clearMenuItem) {
            clearFields(); // Clear all input fields
        }
    }

    // Method to process the input and generate the report
    public void processInput() {
        try {
            // Get the selected movie and input values
            String movie = (String) movieComboBox.getSelectedItem();
            double ticketPrice = Double.parseDouble(ticketPriceField.getText());
            int numberOfTickets = Integer.parseInt(numberOfTicketsField.getText());

            // Validate the inputs
            if (validateInputs(ticketPrice, numberOfTickets)) {
                double totalPrice = calculateTotalPrice(ticketPrice, numberOfTickets); // Calculate the total price
                // Display the report in the report area
                reportArea.setText(generateReport(movie, ticketPrice, numberOfTickets, totalPrice));
                // Save the report to a file
                saveReportToFile(movie, ticketPrice, numberOfTickets, totalPrice);
            } else {
                reportArea.setText("Invalid input detected. Please check the fields.");
            }
        } catch (NumberFormatException ex) {
            reportArea.setText("Please enter valid numbers for ticket price and number of tickets.");
        } catch (IOException ex) {
            reportArea.setText("Error saving report to file.");
        }
    }

    // Method to validate ticket price and number of tickets
    boolean validateInputs(double ticketPrice, int numberOfTickets) {
        return ticketPrice > 0 && numberOfTickets > 0; // Both must be greater than 0
    }

    // Calculate the total price (including tax)
    double calculateTotalPrice(double ticketPrice, int numberOfTickets) {
        return ticketPrice * numberOfTickets * 1.14; // Add 14% tax
    }

    // Generate the report string to display and save
    String generateReport(String movie, double ticketPrice, int numberOfTickets, double totalPrice) {
        return String.format("MOVIE NAME: %s\nMOVIE TICKET PRICE: R %.2f\nNUMBER OF TICKETS: %d\nTOTAL TICKET PRICE: R %.2f",
                movie, ticketPrice, numberOfTickets, totalPrice);
    }

    // Save the generated report to a file
    public void saveReportToFile(String movie, double ticketPrice, int numberOfTickets, double totalPrice) throws IOException {
        try (FileWriter writer = new FileWriter("report.txt")) {
            writer.write(generateReport(movie, ticketPrice, numberOfTickets, totalPrice)); // Write to file
        }
    }

    // Clear all input fields and reset the report area
    public void clearFields() {
        movieComboBox.setSelectedIndex(0); // Reset movie selection
        ticketPriceField.setText(""); // Clear ticket price field
        numberOfTicketsField.setText(""); // Clear number of tickets field
        reportArea.setText(""); // Clear the report area
    }

    // Main method to launch the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MovieTicketApp().setVisible(true)); // Start the GUI
    }
}
