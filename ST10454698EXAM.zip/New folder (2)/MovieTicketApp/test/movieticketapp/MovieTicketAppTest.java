/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package movieticketapp;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MovieTicketAppTest {
    public MovieTicketApp app;

    @Before
    public void setUp() {
        app = new MovieTicketApp();
    }

    @Test
    public void testValidateInputs_ValidInputs() {
        assertTrue("Should return true for positive ticket price and ticket count", 
                   app.validateInputs(100.0, 3));
    }

    @Test
    public void testValidateInputs_InvalidTicketPrice() {
        assertFalse("Should return false for non-positive ticket price", 
                    app.validateInputs(0.0, 3));
    }

    @Test
    public void testValidateInputs_InvalidNumberOfTickets() {
        assertFalse("Should return false for non-positive number of tickets", 
                    app.validateInputs(100.0, 0));
    }

    @Test
    public void testCalculateTotalPrice() {
        double ticketPrice = 100.0;
        int numberOfTickets = 3;
        double expectedTotalPrice = ticketPrice * numberOfTickets * 1.14; // Including VAT

        assertEquals("Total price should be calculated correctly", 
                     expectedTotalPrice, app.calculateTotalPrice(ticketPrice, numberOfTickets), 0.01);
    }

    @Test
    public void testGenerateReport() {
        String movie = "Oppenheimer";
        double ticketPrice = 150.0;
        int numberOfTickets = 2;
        double totalPrice = app.calculateTotalPrice(ticketPrice, numberOfTickets);

        String expectedReport = String.format("MOVIE NAME: %s\nMOVIE TICKET PRICE: R %.2f\nNUMBER OF TICKETS: %d\nTOTAL TICKET PRICE: R %.2f",
                                              movie, ticketPrice, numberOfTickets, totalPrice);

        assertEquals("Report should match the expected format and values", 
                     expectedReport, app.generateReport(movie, ticketPrice, numberOfTickets, totalPrice));
    }
}

